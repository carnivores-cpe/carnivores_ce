Adelphospro Test Dev Build

Contains the following changes:

= Gameplay =
1. Weapon Offsets
2. Weapon Ironsights
3. Sprinting

= Dev =
1. D3D Test Fix Patch
NOTE: If working properly, this patch will enable you to run d3d if you couldn't before,
but NO TEXTURES are applied to the models in the game, thus everything is white with the
exception of the minimap, ammo indicators, and other 2d textures.

= Known Bugs =
1. d3d white land
2. Retarded Walking in Software mode
This might be on my computer only, but for some reason the walking
in software mode is kinda weird and sounds like your riding a horse. 
Please report if you do not have this problem.


Backup your original d3d and software renderer files (v_soft.ren and v_d3d.ren), your res file
(huntdat\_res.txt), and copy the included files in their conterparts places.

Please report any bugs